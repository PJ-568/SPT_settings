To Install: Extract Bepinex and user folder into your SPT folder.

Make sure you have BigBrain and Waypoints for 3.9.0, or SAIN will fail to load!

OLD PRESETS ARE NOT COMPATIBLE.